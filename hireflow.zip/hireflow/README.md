# HireFlow - Applicant Tracking & Interview Panel Scheduling

Spring Boot 3 / Java 17 backend. Layers: controller -> service (business rules) -> repository -> JPA entities.

## Run
    mvn spring-boot:run                                   # in-memory H2 (zero setup)
    mvn spring-boot:run -Dspring-boot.run.profiles=mysql  # MySQL  (edit application-mysql.properties)
    mvn spring-boot:run -Dspring-boot.run.profiles=postgres

Swagger UI: http://localhost:8080/swagger-ui.html   |   H2 console: http://localhost:8080/h2-console
(JDBC URL `jdbc:h2:mem:hireflow`, user `sa`, blank password)

## Entities
JobOpening 1--* Applicant *--1 PipelineStage; InterviewPanel *--1 Applicant, InterviewPanel *--* Interviewer;
Feedback -> (InterviewPanel, Interviewer, Applicant).

## API
| Method | Path | Purpose |
|---|---|---|
| POST | /api/jobs | create job opening |
| GET | /api/jobs?page=0&size=10&sort=createdAt,desc | list (paginated, sortable) |
| POST | /api/jobs/{id}/applications | apply (starts at SCREENING) |
| GET | /api/jobs/{id}/applicants | list applicants |
| GET | /api/jobs/{id}/funnel | applicant counts per stage |
| PUT | /api/applicants/{id}/stage | move stage `{"targetStage":"INTERVIEW"}` |
| POST | /api/interviewers | create interviewer |
| POST | /api/panels | schedule panel |
| POST | /api/panels/{id}/feedback | submit feedback |
| GET | /api/applicants/{id}/feedback | feedback for applicant |

## Business rules (service layer -> HTTP 409 with clear message)
- Interviewer double-booking (overlapping time ranges) is rejected before saving.
- Applicant cannot move to OFFER without >= 1 HIRE feedback.
- Also: no skipping stages, HIRED/REJECTED are final, panels only for INTERVIEW-stage applicants,
  only panel members give feedback (once per panel), no duplicate applications, closed jobs reject applications.

## Sample flow (Postman)
1. POST /api/jobs                {"title":"Backend Dev","department":"Engineering","description":"Java"}
2. POST /api/jobs/1/applications {"fullName":"Asha","email":"asha@x.com"}
3. POST /api/interviewers        {"fullName":"Ravi","email":"ravi@x.com"}   (and a second one)
4. PUT  /api/applicants/1/stage  {"targetStage":"OFFER"}  -> 409 (must go to INTERVIEW first)
5. PUT  /api/applicants/1/stage  {"targetStage":"INTERVIEW"}
6. POST /api/panels  {"applicantId":1,"interviewerIds":[1,2],"startTime":"2030-01-10T10:00:00","endTime":"2030-01-10T11:00:00"}
7. POST /api/panels  (same interviewer, overlapping time) -> 409 conflict
8. PUT  /api/applicants/1/stage  {"targetStage":"OFFER"}  -> 409 (no positive feedback yet)
9. POST /api/panels/1/feedback {"interviewerId":1,"rating":5,"comments":"Great","recommendation":"HIRE"}
10. PUT /api/applicants/1/stage  {"targetStage":"OFFER"}  -> 200
11. GET  /api/jobs/1/funnel
