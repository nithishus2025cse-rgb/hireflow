package com.hireflow.dto;

import com.hireflow.model.StageName;
import java.util.Map;

public record FunnelResponse(Long jobOpeningId, String title, long totalApplicants, Map<StageName, Long> countsByStage) { }
