package com.hireflow.dto;

import com.hireflow.model.Feedback;
import com.hireflow.model.Recommendation;
import java.time.LocalDateTime;

public record FeedbackResponse(Long id, Long panelId, Long interviewerId, Long applicantId,
                               int rating, String comments, Recommendation recommendation,
                               LocalDateTime submittedAt) {
    public static FeedbackResponse from(Feedback f) {
        return new FeedbackResponse(f.getId(), f.getPanel().getId(), f.getInterviewer().getId(),
                f.getApplicant().getId(), f.getRating(), f.getComments(), f.getRecommendation(), f.getSubmittedAt());
    }
}
