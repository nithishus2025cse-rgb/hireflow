package com.hireflow.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record ApplicationRequest(@NotBlank String fullName, @NotBlank @Email String email) { }
