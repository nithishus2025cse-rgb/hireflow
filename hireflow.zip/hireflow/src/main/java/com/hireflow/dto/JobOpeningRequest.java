package com.hireflow.dto;

import jakarta.validation.constraints.NotBlank;

public record JobOpeningRequest(@NotBlank String title, @NotBlank String department, String description) { }
