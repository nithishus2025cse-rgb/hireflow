package com.hireflow.dto;

import com.hireflow.model.Interviewer;
import com.hireflow.model.InterviewPanel;
import java.time.LocalDateTime;
import java.util.List;

public record PanelResponse(Long id, Long applicantId, List<String> interviewers,
                            LocalDateTime startTime, LocalDateTime endTime) {
    public static PanelResponse from(InterviewPanel p) {
        return new PanelResponse(p.getId(), p.getApplicant().getId(),
                p.getInterviewers().stream().map(Interviewer::getFullName).sorted().toList(),
                p.getStartTime(), p.getEndTime());
    }
}
