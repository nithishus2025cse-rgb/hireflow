package com.hireflow.dto;

import com.hireflow.model.StageName;
import jakarta.validation.constraints.NotNull;

public record StageChangeRequest(@NotNull StageName targetStage) { }
