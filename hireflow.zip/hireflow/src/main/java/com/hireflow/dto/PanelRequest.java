package com.hireflow.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;
import java.util.List;

public record PanelRequest(
        @NotNull @Positive Long applicantId,
        @NotEmpty List<@NotNull Long> interviewerIds,
        @NotNull @Future LocalDateTime startTime,
        @NotNull LocalDateTime endTime) { }
