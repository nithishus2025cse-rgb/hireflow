package com.hireflow.dto;

import com.hireflow.model.Recommendation;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record FeedbackRequest(
        @NotNull @Positive Long interviewerId,
        @NotNull @Min(1) @Max(5) Integer rating,
        String comments,
        @NotNull Recommendation recommendation) { }
