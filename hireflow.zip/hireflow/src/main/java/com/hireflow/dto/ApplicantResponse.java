package com.hireflow.dto;

import com.hireflow.model.Applicant;
import java.time.LocalDateTime;

public record ApplicantResponse(Long id, String fullName, String email, Long jobOpeningId,
                                String stage, LocalDateTime appliedAt) {
    public static ApplicantResponse from(Applicant a) {
        return new ApplicantResponse(a.getId(), a.getFullName(), a.getEmail(),
                a.getJobOpening().getId(), a.getCurrentStage().getName().name(), a.getAppliedAt());
    }
}
