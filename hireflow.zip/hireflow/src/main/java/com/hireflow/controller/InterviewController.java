package com.hireflow.controller;

import com.hireflow.dto.*;
import com.hireflow.model.Interviewer;
import com.hireflow.service.InterviewService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class InterviewController {
    private final InterviewService interviews;

    public InterviewController(InterviewService interviews) { this.interviews = interviews; }

    @PostMapping("/interviewers")
    @ResponseStatus(HttpStatus.CREATED)
    public Interviewer createInterviewer(@Valid @RequestBody InterviewerRequest req) {
        return interviews.createInterviewer(req);
    }

    @GetMapping("/interviewers")
    public List<Interviewer> interviewers() { return interviews.listInterviewers(); }

    // Feature 3: schedule an interview panel (availability checked in the service)
    @PostMapping("/panels")
    @ResponseStatus(HttpStatus.CREATED)
    public PanelResponse schedule(@Valid @RequestBody PanelRequest req) { return interviews.schedule(req); }

    @GetMapping("/panels/{id}")
    public PanelResponse panel(@PathVariable Long id) { return interviews.getPanel(id); }

    // Feature 4: interviewers submit feedback + recommendation
    @PostMapping("/panels/{id}/feedback")
    @ResponseStatus(HttpStatus.CREATED)
    public FeedbackResponse feedback(@PathVariable Long id, @Valid @RequestBody FeedbackRequest req) {
        return interviews.submitFeedback(id, req);
    }
}
