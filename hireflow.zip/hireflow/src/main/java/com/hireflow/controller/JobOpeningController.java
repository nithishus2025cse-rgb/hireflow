package com.hireflow.controller;

import com.hireflow.dto.*;
import com.hireflow.model.JobOpening;
import com.hireflow.service.ApplicantService;
import com.hireflow.service.JobOpeningService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/jobs")
public class JobOpeningController {
    private final JobOpeningService jobs;
    private final ApplicantService applicants;

    public JobOpeningController(JobOpeningService jobs, ApplicantService applicants) {
        this.jobs = jobs;
        this.applicants = applicants;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public JobOpening create(@Valid @RequestBody JobOpeningRequest req) { return jobs.create(req); }

    /** Supports ?page=0&size=10&sort=createdAt,desc */
    @GetMapping
    public Page<JobOpening> list(@PageableDefault(size = 10, sort = "createdAt") Pageable pageable) {
        return jobs.list(pageable);
    }

    @GetMapping("/{id}")
    public JobOpening get(@PathVariable Long id) { return jobs.get(id); }

    // Feature 1: receive applications against a job opening
    @PostMapping("/{id}/applications")
    @ResponseStatus(HttpStatus.CREATED)
    public ApplicantResponse apply(@PathVariable Long id, @Valid @RequestBody ApplicationRequest req) {
        return applicants.apply(id, req);
    }

    @GetMapping("/{id}/applicants")
    public List<ApplicantResponse> applicants(@PathVariable Long id) { return applicants.listForJob(id); }

    // Feature 5: pipeline funnel counts
    @GetMapping("/{id}/funnel")
    public FunnelResponse funnel(@PathVariable Long id) { return jobs.funnel(id); }
}
