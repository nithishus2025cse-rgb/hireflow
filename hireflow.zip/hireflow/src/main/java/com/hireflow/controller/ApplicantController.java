package com.hireflow.controller;

import com.hireflow.dto.*;
import com.hireflow.service.ApplicantService;
import com.hireflow.service.InterviewService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applicants")
public class ApplicantController {
    private final ApplicantService applicants;
    private final InterviewService interviews;

    public ApplicantController(ApplicantService applicants, InterviewService interviews) {
        this.applicants = applicants;
        this.interviews = interviews;
    }

    @GetMapping("/{id}")
    public ApplicantResponse get(@PathVariable Long id) { return applicants.get(id); }

    // Feature 2: move applicant through the pipeline
    @PutMapping("/{id}/stage")
    public ApplicantResponse moveStage(@PathVariable Long id, @Valid @RequestBody StageChangeRequest req) {
        return applicants.moveToStage(id, req.targetStage());
    }

    @GetMapping("/{id}/feedback")
    public List<FeedbackResponse> feedback(@PathVariable Long id) { return interviews.feedbackForApplicant(id); }
}
