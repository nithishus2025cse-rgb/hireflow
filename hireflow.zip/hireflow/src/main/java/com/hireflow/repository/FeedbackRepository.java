package com.hireflow.repository;

import com.hireflow.model.Feedback;
import com.hireflow.model.Recommendation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    boolean existsByPanelIdAndInterviewerId(Long panelId, Long interviewerId);

    boolean existsByApplicantIdAndRecommendation(Long applicantId, Recommendation recommendation);

    List<Feedback> findByApplicantId(Long applicantId);
}
