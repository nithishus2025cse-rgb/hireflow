package com.hireflow.repository;

import com.hireflow.model.InterviewPanel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface InterviewPanelRepository extends JpaRepository<InterviewPanel, Long> {

    /** Names of interviewers (from the given ids) who already have a panel overlapping [start, end). */
    @Query("select distinct i.fullName from InterviewPanel p join p.interviewers i " +
           "where i.id in :ids and p.startTime < :end and p.endTime > :start")
    List<String> findConflictingInterviewers(@Param("ids") Collection<Long> ids,
                                             @Param("start") LocalDateTime start,
                                             @Param("end") LocalDateTime end);

    List<InterviewPanel> findByApplicantId(Long applicantId);
}
