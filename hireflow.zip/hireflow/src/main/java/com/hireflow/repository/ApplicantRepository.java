package com.hireflow.repository;

import com.hireflow.model.Applicant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ApplicantRepository extends JpaRepository<Applicant, Long> {
    boolean existsByEmailIgnoreCaseAndJobOpeningId(String email, Long jobOpeningId);

    List<Applicant> findByJobOpeningId(Long jobOpeningId);

    /** Returns rows of [StageName, count] for the funnel view. */
    @Query("select a.currentStage.name, count(a) from Applicant a " +
           "where a.jobOpening.id = :jobId group by a.currentStage.name")
    List<Object[]> countByStageForJob(@Param("jobId") Long jobId);
}
