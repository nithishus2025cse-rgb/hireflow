package com.hireflow.repository;

import com.hireflow.model.PipelineStage;
import com.hireflow.model.StageName;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PipelineStageRepository extends JpaRepository<PipelineStage, Long> {
    Optional<PipelineStage> findByName(StageName name);
}
