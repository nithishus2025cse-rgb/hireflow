package com.hireflow.repository;

import com.hireflow.model.Interviewer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterviewerRepository extends JpaRepository<Interviewer, Long> {
    boolean existsByEmailIgnoreCase(String email);
}
