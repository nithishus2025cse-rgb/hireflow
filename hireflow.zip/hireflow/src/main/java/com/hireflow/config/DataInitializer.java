package com.hireflow.config;

import com.hireflow.model.PipelineStage;
import com.hireflow.model.StageName;
import com.hireflow.repository.PipelineStageRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Seeds the pipeline stages on startup if they don't exist yet. */
@Component
public class DataInitializer implements CommandLineRunner {
    private final PipelineStageRepository stages;

    public DataInitializer(PipelineStageRepository stages) { this.stages = stages; }

    @Override
    public void run(String... args) {
        for (StageName s : StageName.values()) {
            if (stages.findByName(s).isEmpty()) {
                stages.save(new PipelineStage(s, s.ordinal()));
            }
        }
    }
}
