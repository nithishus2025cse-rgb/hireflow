package com.hireflow.service;

import com.hireflow.dto.FunnelResponse;
import com.hireflow.dto.JobOpeningRequest;
import com.hireflow.exception.ResourceNotFoundException;
import com.hireflow.model.JobOpening;
import com.hireflow.model.StageName;
import com.hireflow.repository.ApplicantRepository;
import com.hireflow.repository.JobOpeningRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumMap;
import java.util.Map;

@Service
public class JobOpeningService {
    private final JobOpeningRepository jobs;
    private final ApplicantRepository applicants;

    public JobOpeningService(JobOpeningRepository jobs, ApplicantRepository applicants) {
        this.jobs = jobs;
        this.applicants = applicants;
    }

    @Transactional
    public JobOpening create(JobOpeningRequest req) {
        JobOpening job = new JobOpening();
        job.setTitle(req.title());
        job.setDepartment(req.department());
        job.setDescription(req.description());
        return jobs.save(job);
    }

    public Page<JobOpening> list(Pageable pageable) { return jobs.findAll(pageable); }

    public JobOpening get(Long id) {
        return jobs.findById(id).orElseThrow(() -> new ResourceNotFoundException("JobOpening", id));
    }

    @Transactional(readOnly = true)
    public FunnelResponse funnel(Long jobId) {
        JobOpening job = get(jobId);
        Map<StageName, Long> counts = new EnumMap<>(StageName.class);
        for (StageName s : StageName.values()) counts.put(s, 0L);   // show empty stages as 0
        long total = 0;
        for (Object[] row : applicants.countByStageForJob(jobId)) {
            long c = (Long) row[1];
            counts.put((StageName) row[0], c);
            total += c;
        }
        return new FunnelResponse(job.getId(), job.getTitle(), total, counts);
    }
}
