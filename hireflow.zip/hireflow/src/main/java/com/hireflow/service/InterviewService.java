package com.hireflow.service;

import com.hireflow.dto.*;
import com.hireflow.exception.BusinessRuleException;
import com.hireflow.exception.ResourceNotFoundException;
import com.hireflow.model.*;
import com.hireflow.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class InterviewService {
    private final InterviewerRepository interviewers;
    private final InterviewPanelRepository panels;
    private final ApplicantRepository applicants;
    private final FeedbackRepository feedbacks;

    public InterviewService(InterviewerRepository interviewers, InterviewPanelRepository panels,
                            ApplicantRepository applicants, FeedbackRepository feedbacks) {
        this.interviewers = interviewers;
        this.panels = panels;
        this.applicants = applicants;
        this.feedbacks = feedbacks;
    }

    @Transactional
    public Interviewer createInterviewer(InterviewerRequest req) {
        if (interviewers.existsByEmailIgnoreCase(req.email()))
            throw new BusinessRuleException("An interviewer with email " + req.email() + " already exists");
        Interviewer i = new Interviewer();
        i.setFullName(req.fullName());
        i.setEmail(req.email());
        return interviewers.save(i);
    }

    public List<Interviewer> listInterviewers() { return interviewers.findAll(); }

    /** Availability is checked BEFORE saving, so a conflicting request never touches the data. */
    @Transactional
    public PanelResponse schedule(PanelRequest req) {
        if (!req.endTime().isAfter(req.startTime()))
            throw new BusinessRuleException("endTime must be after startTime");

        Applicant applicant = applicants.findById(req.applicantId())
                .orElseThrow(() -> new ResourceNotFoundException("Applicant", req.applicantId()));
        if (applicant.getCurrentStage().getName() != StageName.INTERVIEW)
            throw new BusinessRuleException("Interviews can only be scheduled for applicants in the INTERVIEW stage "
                    + "(current stage: " + applicant.getCurrentStage().getName() + ")");

        Set<Long> ids = new HashSet<>(req.interviewerIds());
        List<Interviewer> found = interviewers.findAllById(ids);
        if (found.size() != ids.size()) {
            Set<Long> foundIds = new HashSet<>();
            found.forEach(i -> foundIds.add(i.getId()));
            ids.removeAll(foundIds);
            throw new ResourceNotFoundException("Interviewer", ids.iterator().next());
        }

        List<String> busy = panels.findConflictingInterviewers(ids, req.startTime(), req.endTime());
        if (!busy.isEmpty())
            throw new BusinessRuleException("Scheduling conflict: " + String.join(", ", busy)
                    + " already ha" + (busy.size() == 1 ? "s" : "ve") + " a booking that overlaps "
                    + req.startTime() + " - " + req.endTime());

        InterviewPanel panel = new InterviewPanel();
        panel.setApplicant(applicant);
        panel.setInterviewers(new HashSet<>(found));
        panel.setStartTime(req.startTime());
        panel.setEndTime(req.endTime());
        return PanelResponse.from(panels.save(panel));
    }

    @Transactional(readOnly = true)
    public PanelResponse getPanel(Long id) {
        return PanelResponse.from(findPanel(id));
    }

    @Transactional
    public FeedbackResponse submitFeedback(Long panelId, FeedbackRequest req) {
        InterviewPanel panel = findPanel(panelId);
        Interviewer interviewer = interviewers.findById(req.interviewerId())
                .orElseThrow(() -> new ResourceNotFoundException("Interviewer", req.interviewerId()));

        if (!panel.getInterviewers().contains(interviewer))
            throw new BusinessRuleException("Interviewer " + interviewer.getFullName() + " is not on panel " + panelId);
        if (feedbacks.existsByPanelIdAndInterviewerId(panelId, interviewer.getId()))
            throw new BusinessRuleException("Feedback from " + interviewer.getFullName() + " was already submitted for this panel");

        Feedback f = new Feedback();
        f.setPanel(panel);
        f.setInterviewer(interviewer);
        f.setApplicant(panel.getApplicant());
        f.setRating(req.rating());
        f.setComments(req.comments());
        f.setRecommendation(req.recommendation());
        return FeedbackResponse.from(feedbacks.save(f));
    }

    @Transactional(readOnly = true)
    public List<FeedbackResponse> feedbackForApplicant(Long applicantId) {
        if (!applicants.existsById(applicantId)) throw new ResourceNotFoundException("Applicant", applicantId);
        return feedbacks.findByApplicantId(applicantId).stream().map(FeedbackResponse::from).toList();
    }

    private InterviewPanel findPanel(Long id) {
        return panels.findById(id).orElseThrow(() -> new ResourceNotFoundException("InterviewPanel", id));
    }
}
