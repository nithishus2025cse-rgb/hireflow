package com.hireflow.service;

import com.hireflow.dto.ApplicantResponse;
import com.hireflow.dto.ApplicationRequest;
import com.hireflow.exception.BusinessRuleException;
import com.hireflow.exception.ResourceNotFoundException;
import com.hireflow.model.*;
import com.hireflow.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ApplicantService {
    private final ApplicantRepository applicants;
    private final JobOpeningRepository jobs;
    private final PipelineStageRepository stages;
    private final FeedbackRepository feedbacks;

    public ApplicantService(ApplicantRepository applicants, JobOpeningRepository jobs,
                            PipelineStageRepository stages, FeedbackRepository feedbacks) {
        this.applicants = applicants;
        this.jobs = jobs;
        this.stages = stages;
        this.feedbacks = feedbacks;
    }

    @Transactional
    public ApplicantResponse apply(Long jobId, ApplicationRequest req) {
        JobOpening job = jobs.findById(jobId).orElseThrow(() -> new ResourceNotFoundException("JobOpening", jobId));
        if (job.getStatus() != JobStatus.OPEN)
            throw new BusinessRuleException("Job opening " + jobId + " is closed and no longer accepts applications");
        if (applicants.existsByEmailIgnoreCaseAndJobOpeningId(req.email(), jobId))
            throw new BusinessRuleException("An application from " + req.email() + " already exists for this job opening");

        Applicant a = new Applicant();
        a.setFullName(req.fullName());
        a.setEmail(req.email());
        a.setJobOpening(job);
        a.setCurrentStage(stage(StageName.SCREENING));
        return ApplicantResponse.from(applicants.save(a));
    }

    @Transactional(readOnly = true)
    public List<ApplicantResponse> listForJob(Long jobId) {
        if (!jobs.existsById(jobId)) throw new ResourceNotFoundException("JobOpening", jobId);
        return applicants.findByJobOpeningId(jobId).stream().map(ApplicantResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public ApplicantResponse get(Long id) {
        return ApplicantResponse.from(find(id));
    }

    /**
     * Rules enforced here (service layer):
     *  1. HIRED / REJECTED applicants are final.
     *  2. Stages move one step forward at a time (no skipping); REJECTED is allowed from any active stage.
     *  3. Moving to OFFER requires at least one positive (HIRE) interview feedback.
     */
    @Transactional
    public ApplicantResponse moveToStage(Long applicantId, StageName target) {
        Applicant a = find(applicantId);
        StageName current = a.getCurrentStage().getName();

        if (current == StageName.HIRED || current == StageName.REJECTED)
            throw new BusinessRuleException("Applicant is already " + current + " and cannot be moved further");
        if (target == current)
            throw new BusinessRuleException("Applicant is already in stage " + current);

        if (target != StageName.REJECTED && target.ordinal() != current.ordinal() + 1)
            throw new BusinessRuleException("Invalid transition " + current + " -> " + target
                    + ". Next allowed stage is " + StageName.values()[current.ordinal() + 1] + " (or REJECTED)");

        if (target == StageName.OFFER
                && !feedbacks.existsByApplicantIdAndRecommendation(applicantId, Recommendation.HIRE))
            throw new BusinessRuleException("Cannot move applicant to OFFER: at least one positive (HIRE) "
                    + "interview feedback is required");

        a.setCurrentStage(stage(target));
        return ApplicantResponse.from(applicants.save(a));
    }

    Applicant find(Long id) {
        return applicants.findById(id).orElseThrow(() -> new ResourceNotFoundException("Applicant", id));
    }

    private PipelineStage stage(StageName name) {
        return stages.findByName(name).orElseThrow(() -> new IllegalStateException("Stage not seeded: " + name));
    }
}
