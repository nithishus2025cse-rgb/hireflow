package com.hireflow.model;

public enum Recommendation { HIRE, NO_HIRE }
