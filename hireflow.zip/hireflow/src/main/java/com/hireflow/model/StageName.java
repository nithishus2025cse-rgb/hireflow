package com.hireflow.model;

/** Order matters: the ordinal defines the forward flow of the pipeline. REJECTED is a terminal side-exit. */
public enum StageName { SCREENING, INTERVIEW, OFFER, HIRED, REJECTED }
