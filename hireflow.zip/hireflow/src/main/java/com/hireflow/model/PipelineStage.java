package com.hireflow.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor
public class PipelineStage {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, unique = true)
    private StageName name;

    @Column(nullable = false)
    private int stageOrder;

    public PipelineStage(StageName name, int stageOrder) {
        this.name = name;
        this.stageOrder = stageOrder;
    }
}
